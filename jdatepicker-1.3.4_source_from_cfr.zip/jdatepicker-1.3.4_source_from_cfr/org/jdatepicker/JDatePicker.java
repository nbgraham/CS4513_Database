/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker;

import org.jdatepicker.JDatePanel;

public interface JDatePicker
extends JDatePanel {
    public void setTextEditable(boolean var1);

    public boolean isTextEditable();

    public void setButtonFocusable(boolean var1);

    public boolean getButtonFocusable();
}

