/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker.graphics;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

public class JNextIcon
implements Icon {
    protected int width;
    protected int height;
    protected int[] xPoints = new int[3];
    protected int[] yPoints = new int[3];
    private boolean doubleArrow;

    public JNextIcon(int width, int height) {
        this.setDimension(width, height);
        this.doubleArrow = false;
    }

    public JNextIcon(int width, int height, boolean doubleArrow) {
        this.setDimension(width, height);
        this.doubleArrow = doubleArrow;
    }

    public void setDoubleArrow(boolean doubleArrow) {
        this.doubleArrow = doubleArrow;
    }

    public boolean getDoubleArrow() {
        return this.doubleArrow;
    }

    public int getIconWidth() {
        return this.width;
    }

    public int getIconHeight() {
        return this.height;
    }

    public void setDimension(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void paintIcon(Component c, Graphics g, int x, int y) {
        if (this.doubleArrow) {
            this.xPoints[0] = x + this.width / 2;
            this.yPoints[0] = y + this.height / 2;
            this.xPoints[1] = x;
            this.yPoints[1] = y - 1;
            this.xPoints[2] = x;
            this.yPoints[2] = y + this.height;
            g.setColor(Color.BLACK);
            g.fillPolygon(this.xPoints, this.yPoints, 3);
            this.xPoints[0] = x + this.width;
            this.yPoints[0] = y + this.height / 2;
            this.xPoints[1] = x + this.width / 2;
            this.yPoints[1] = y - 1;
            this.xPoints[2] = x + this.width / 2;
            this.yPoints[2] = y + this.height;
            g.setColor(Color.BLACK);
            g.fillPolygon(this.xPoints, this.yPoints, 3);
        } else {
            this.xPoints[0] = x + this.width;
            this.yPoints[0] = y + this.height / 2;
            this.xPoints[1] = x;
            this.yPoints[1] = y - 1;
            this.xPoints[2] = x;
            this.yPoints[2] = y + this.height;
            g.setColor(Color.BLACK);
            g.fillPolygon(this.xPoints, this.yPoints, 3);
        }
    }
}

