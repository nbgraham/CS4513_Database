/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker;

import java.awt.event.ActionListener;
import org.jdatepicker.DateModel;

public interface JDateComponent {
    public DateModel<?> getModel();

    public void addActionListener(ActionListener var1);

    public void removeActionListener(ActionListener var1);
}

