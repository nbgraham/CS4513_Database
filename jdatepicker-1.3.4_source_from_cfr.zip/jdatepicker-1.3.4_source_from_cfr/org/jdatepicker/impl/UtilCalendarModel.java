/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker.impl;

import java.util.Calendar;
import org.jdatepicker.AbstractDateModel;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class UtilCalendarModel
extends AbstractDateModel<Calendar> {
    public UtilCalendarModel() {
        this(null);
    }

    public UtilCalendarModel(Calendar value) {
        this.setValue(value);
    }

    @Override
    protected Calendar fromCalendar(Calendar from) {
        return (Calendar)from.clone();
    }

    @Override
    protected Calendar toCalendar(Calendar from) {
        return (Calendar)from.clone();
    }
}

