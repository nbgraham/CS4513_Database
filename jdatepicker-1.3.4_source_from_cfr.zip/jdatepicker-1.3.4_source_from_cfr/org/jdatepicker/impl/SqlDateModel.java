/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker.impl;

import java.util.Calendar;
import java.util.Date;
import org.jdatepicker.AbstractDateModel;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SqlDateModel
extends AbstractDateModel<java.sql.Date> {
    public SqlDateModel() {
        this(null);
    }

    public SqlDateModel(java.sql.Date value) {
        this.setValue(value);
    }

    @Override
    protected java.sql.Date fromCalendar(Calendar from) {
        return new java.sql.Date(from.getTimeInMillis());
    }

    @Override
    protected Calendar toCalendar(java.sql.Date from) {
        Calendar to = Calendar.getInstance();
        to.setTime(from);
        return to;
    }
}

