/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker;

import java.beans.PropertyChangeListener;
import javax.swing.event.ChangeListener;

public interface DateModel<T> {
    public void addChangeListener(ChangeListener var1);

    public void removeChangeListener(ChangeListener var1);

    public int getYear();

    public void setYear(int var1);

    public int getMonth();

    public void setMonth(int var1);

    public int getDay();

    public void setDay(int var1);

    public void setDate(int var1, int var2, int var3);

    public void addYear(int var1);

    public void addMonth(int var1);

    public void addDay(int var1);

    public T getValue();

    public void setValue(T var1);

    public boolean isSelected();

    public void setSelected(boolean var1);

    public void addPropertyChangeListener(PropertyChangeListener var1);

    public void removePropertyChangeListener(PropertyChangeListener var1);
}

