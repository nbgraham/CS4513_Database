/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker;

import org.jdatepicker.JDateComponent;

public interface JDatePanel
extends JDateComponent {
    public void setShowYearButtons(boolean var1);

    public boolean isShowYearButtons();

    public void setDoubleClickAction(boolean var1);

    public boolean isDoubleClickAction();
}

