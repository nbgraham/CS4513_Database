/*
 * Decompiled with CFR 0_118.
 */
package org.jdatepicker.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class JDatePickerUtil {
    public static DateFormat getMediumDateFormat() {
        return SimpleDateFormat.getDateInstance(2);
    }
}

